# API textbelt.com
API_KEY = ""

# List of numbers telephonics
file = "numbers.txt"